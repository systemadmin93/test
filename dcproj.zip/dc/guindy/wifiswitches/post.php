<!DOCTYPE HTML>
<html>
<body>
<?php
include("../DBConnection.php");
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{ 
$inWS1 = $_POST["wf1"];
$inWS2 = $_POST["wf2"];
$inWS3 = $_POST["wf3"];
$inWS4 = $_POST["ar1"];
$inWS5 = $_POST["ar2"];
$inWS6 = $_POST["hp1"];
$inWS7 = $_POST["hp2"];
$inWS8 = $_POST["hp3"];
$inWS9 = $_POST["hp4"];
$inWS10 = $_POST["hp5"];
$inWS11 = $_POST["hp6"];
$inWS12 = $_POST["hp7"];
$inWS13 = $_POST["hp8"];
$inWS14 = $_POST["hp9"];
$inWS15 = $_POST["hp10"];
$inWS16 = $_POST["hp11"];
$inWS17 = $_POST["hp12"];
$inWS18 = $_POST["hp13"];
$inWS19 = $_POST["hp14"];
$inWS20 = $_POST["hp15"];
$stmt = $db->prepare("INSERT INTO `wifiandswitches`(`192.168.5.14`, `192.168.5.18`, `192.168.5.20`, `192.168.5.181`, `192.168.5.182`, `192.168.5.233`, `192.168.5.234`, `192.168.5.235`, `192.168.5.236`, `192.168.5.237`, `192.168.5.238`, `192.168.5.239`,`192.168.5.240`, `192.168.5.241`, `192.168.5.242`, `192.168.5.244`, `192.168.5.245`, `192.168.5.246`, `192.168.5.247`, `192.168.5.250`) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"); //Fetching all the records with input credentials
$stmt->bind_param('ssssssssssssssssssss', $inWS1, $inWS2, $inWS3, $inWS4, $inWS5, $inWS6, $inWS7, $inWS8, $inWS9, $inWS10, $inWS11, $inWS12, $inWS13, $inWS14, $inWS15, $inWS16, $inWS17, $inWS18, $inWS19, $inWS20);  //Where s indicates string type. You can use i-integer, d-double
echo $stmt->execute();
echo $result = $stmt->affected_rows;
$stmt -> close();
$db -> close(); 
if($result > 0)
{
header("location: posted.php"); // user will be taken to the success page
}
else
{
echo "Oops. Something went wrong. Please try again"; 
?>
<a href="isp_posting.php">Try Login</a>
<?php 
}
}
?>
</body> 
</html>