<?php
include("../DBConnection.php");
$result = mysqli_query($db,"SELECT * FROM wifiandswitches");
?>
<!DOCTYPE html>
<html>
 <head>
 <title># Guindy Wifi and Switches View #</title>
 </head>
<body>
<center> <h1> Guindy Wifi and Switches's Status Report </h1></center>
<?php
if (mysqli_num_rows($result) > 0) {
?>
<table align="center" border="2" style="background-color:powderblue;" style="width: 11px; height: 100px;" >
  <tr>
   	<th>192.168.5.14 S10Conference_Wifi</th>
	<th>192.168.5.18 S10Angels_Wifi</th>
	<th>192.168.5.20 S10health_Wifi</th>
	<th>192.168.5.181 Aruba_Core1</th>
	<th>192.168.5.182 Aruba_Core2</th>
	<th>192.168.5.233 HP 1</th>
	<th>192.168.5.234 HP 2</th>
	<th>192.168.5.235 HP 3</th>
	<th>192.168.5.236 HP 4</th>
	<th>192.168.5.237 HP 5</th>
	<th>192.168.5.238 HP 6</th>
	<th>192.168.5.239 HP 7</th>
	<th>192.168.5.240 HP 8</th>
	<th>192.168.5.241 HP 9</th>
	<th>192.168.5.242 HP 10</th>
	<th>192.168.5.244 HP 11</th>
	<th>192.168.5.245 HP 12</th>
	<th>192.168.5.246 HP 13</th>
	<th>192.168.5.247 HP 14</th>
	<th>192.168.5.250 HP 15</th>
	<th>checked on</th>
  </tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
   	<td><?php echo $row["192.168.5.14"]; ?></td>
	<td><?php echo $row["192.168.5.18"]; ?></td>
	<td><?php echo $row["192.168.5.20"]; ?></td>
	<td><?php echo $row["192.168.5.181"]; ?></td>
	<td><?php echo $row["192.168.5.182"]; ?></td>
	<td><?php echo $row["192.168.5.233"]; ?></td>
	<td><?php echo $row["192.168.5.234"]; ?></td>
	<td><?php echo $row["192.168.5.235"]; ?></td>
	<td><?php echo $row["192.168.5.236"]; ?></td>
	<td><?php echo $row["192.168.5.237"]; ?></td>
	<td><?php echo $row["192.168.5.238"]; ?></td>
	<td><?php echo $row["192.168.5.239"]; ?></td>
	<td><?php echo $row["192.168.5.240"]; ?></td>
	<td><?php echo $row["192.168.5.241"]; ?></td>
	<td><?php echo $row["192.168.5.242"]; ?></td>
	<td><?php echo $row["192.168.5.244"]; ?></td>
	<td><?php echo $row["192.168.5.245"]; ?></td>
	<td><?php echo $row["192.168.5.246"]; ?></td>
	<td><?php echo $row["192.168.5.247"]; ?></td> 
	<td><?php echo $row["192.168.5.250"]; ?></td>
	 <td><?php echo $row["postdate"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "No result found";
}
?>
 </body>
</html>