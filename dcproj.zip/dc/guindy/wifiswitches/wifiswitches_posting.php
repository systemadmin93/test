<!DOCTYPE HTML>
<html>
<head>
<title># Guindy Switches and Wifi #</title>
<!-- Using external stylesheet to make the registration form look attractive -->
<link rel = "stylesheet" type = "text/css" href="Style.css"/>
<!-- Javascript validation for user inputs -->
<center> <h1>Guindy Switch and Wifi Status on/off </center>
</head>
<body>
<br>
<form name="register" method="post" action="post.php" >
<table align="center" >
<tr><th>Wifi Devices</th></tr>
<tr>
<td>S10Conference Wifi</td><td>192.168.5.14</td>
<td><input type="radio" name="wf1" value="on" />ON <input type="radio" name="wf1" value="off" />OFF</td>
</tr>
<tr>
<td>S10Angels Wifi</td><td>192.168.5.18</td>
<td><input type="radio" name="wf2" value="on" />ON <input type="radio" name="wf2" value="off" />OFF</td>
</tr>
<tr>
<td>S10health Wifi</td><td>192.168.5.20</td>
<td><input type="radio" name="wf3" value="on" />ON <input type="radio" name="wf3" value="off" />OFF</td>
</tr>
<tr><th>Aruba L3 Core Switches</th></tr>
<tr>
<td>Primary Switch</td><td>192.168.5.181</td>
<td><input type="radio" name="ar1" value="on" />ON <input type="radio" name="ar1" value="off" />OFF</td>
</tr>
<tr>
<td>Secondary Switch</td><td>192.168.5.182</td>
<td><input type="radio" name="ar2" value="on" />ON <input type="radio" name="ar2" value="off" />OFF</td>
</tr>
<tr>
<tr><th> HP L2 Switches</th></tr>
<td>switch 1</td><td>192.168.5.233</td>
<td><input type="radio" name="hp1" value="on" />ON <input type="radio" name="hp1" value="off" />OFF</td>
</tr>
<tr>
<td>switch 2</td><td>192.168.5.234</td>
<td><input type="radio" name="hp2" value="on" />ON <input type="radio" name="hp2" value="off" />OFF</td>
</tr>
<tr>
<td>switch 3</td><td>192.168.5.235</td>
<td><input type="radio" name="hp3" value="on" />ON <input type="radio" name="hp3" value="off" />OFF</td>
</tr>
<tr>
<td>switch 4</td><td>192.168.5.236</td>
<td><input type="radio" name="hp4" value="on" />ON <input type="radio" name="hp4" value="off" />OFF</td>
</tr>
<tr>
<td>switch 5</td><td>192.168.5.237</td>
<td><input type="radio" name="hp5" value="on" />ON <input type="radio" name="hp5" value="off" />OFF</td>
</tr>
<tr>
<td>switch 6</td><td>192.168.5.238</td>
<td><input type="radio" name="hp6" value="on" />ON <input type="radio" name="hp6" value="off" />OFF</td>
</tr>
<tr>
<td>switch 7</td><td>192.168.5.239</td>
<td><input type="radio" name="hp7" value="on" />ON <input type="radio" name="hp7" value="off" />OFF</td>
</tr>
<tr>
<td>switch 8</td><td>192.168.5.240</td>
<td><input type="radio" name="hp8" value="on" />ON <input type="radio" name="hp8" value="off" />OFF</td>
</tr>
<tr>
<td>switch 9</td><td>192.168.5.241</td>
<td><input type="radio" name="hp9" value="on" />ON <input type="radio" name="hp9" value="off" />OFF</td>
</tr>
<tr>
<td>switch 10</td><td>192.168.5.242</td>
<td><input type="radio" name="hp10" value="on" />ON <input type="radio" name="hp10" value="off" />OFF</td>
</tr>
<tr>
<td>switch 11</td><td>192.168.5.244</td>
<td><input type="radio" name="hp11" value="on" />ON <input type="radio" name="hp11" value="off" />OFF</td>
</tr>
<tr>
<td>switch 12</td><td>192.168.5.245</td>
<td><input type="radio" name="hp12" value="on" />ON <input type="radio" name="hp12" value="off" />OFF</td>
</tr>
<tr>
<td>switch 13</td><td>192.168.5.246</td>
<td><input type="radio" name="hp13" value="on" />ON <input type="radio" name="hp13" value="off" />OFF</td>
</tr>
<tr>
<td>switch 14</td><td>192.168.5.247</td>
<td><input type="radio" name="hp14" value="on" />ON <input type="radio" name="hp14" value="off" />OFF</td>
</tr>
<tr>
<td>switch 15</td><td>192.168.5.250</td>
<td><input type="radio" name="hp15" value="on" />ON <input type="radio" name="hp15" value="off" />OFF</td>
</tr>
<td><input type="submit" value="Update"></input>
<input type="reset" value="Clear"></input></td>
</tr>
</table>
</form>
</body>
</html>