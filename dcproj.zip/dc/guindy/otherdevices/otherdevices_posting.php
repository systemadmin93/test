<!DOCTYPE HTML>
<html>
<head>
<title># Guindy UPS/DVR/Printers/FP Post #</title>
<!-- Using external stylesheet to make the registration form look attractive -->
<link rel = "stylesheet" type = "text/css" href="Style.css"/>
<!-- Javascript validation for user inputs -->
<center> <h1>UPS/DVR/Printers/FP </center>
</head>
<body>
<br>
<form name="register" method="post" action="post.php" >
<table align="center" >
<tr><th>UPS Devices</th></tr>
<tr>
<td>UPS 1</td><td>192.168.5.253</td>
<td><input type="radio" name="ups1" value="on" />ON <input type="radio" name="ups1" value="off" />OFF</td>
</tr>
<tr><th>DVR</th></tr>
<tr>
<td>Camera DVR1</td><td>192.168.5.52</td>
<td><input type="radio" name="dvr1" value="on" />ON <input type="radio" name="dvr1" value="off" />OFF</td>
</tr>
<tr>
<td>Camera DVR1</td><td>192.168.3.205</td>
<td><input type="radio" name="dvr2" value="on" />ON <input type="radio" name="dvr2" value="off" />OFF</td>
</tr>
<tr><th>Printers</th></tr>
<tr>
<td>Cannon</td><td>192.168.5.229</td>
<td><input type="radio" name="p1" value="on" />ON <input type="radio" name="p1" value="off" />OFF</td>
</tr>
<tr>
<td>HP Printer</td><td>192.168.5.252</td>
<td><input type="radio" name="p2" value="on" />ON <input type="radio" name="p2" value="off" />OFF</td>
</tr>
<tr>
<tr><th> FingurePrint Devices</th></tr>
<tr>
<td> Main entrance</td><td>192.168.3.250</td>
<td><input type="radio" name="fp1" value="on" />ON <input type="radio" name="fp1" value="off" />OFF</td>
</tr>
<tr>
<td>Canteen</td><td>192.168.5.249</td>
<td><input type="radio" name="fp2" value="on" />ON <input type="radio" name="fp2" value="off" />OFF</td>
</tr>
<td><input type="submit" value="Update"></input>
<input type="reset" value="Clear"></input></td>
</tr>
</table>
</form>
</body>
</html>