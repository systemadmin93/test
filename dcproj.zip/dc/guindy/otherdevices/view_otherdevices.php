<?php
include("../DBConnection.php");
$result = mysqli_query($db,"SELECT * FROM otherdevices");
?>
<!DOCTYPE html>
<html>
 <head>
 <title># Guindy UPS/DVR/Printer/FP View #</title>
 </head>
<body>
<center> <h1> Guindy UPS/DVR/Printer/FP's Status Report </h1></center>
<?php
if (mysqli_num_rows($result) > 0) {
?>
<table align="center" border="2" style="background-color:powderblue;" style="width: 11px; height: 100px;" >
  <tr>
   	<th>192.168.5.253 UPS 1</th>
	<th>192.168.5.52  DVR1</th>
	<th>192.168.3.205 DVR2</th>
	<th>192.168.5.229 Cannon</th>
	<th>192.168.5.252 HP Printer</th>
	<th>192.168.3.250 MAINEntranceFP</th>
	<th>192.168.5.249 CanteenFP</th>
	<th>checked on       </th>
  </tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
   	<td><?php echo $row["192.168.5.253"]; ?></td>
	<td><?php echo $row["192.168.5.52"];  ?></td>
	<td><?php echo $row["192.168.3.205"]; ?></td>
	<td><?php echo $row["192.168.5.229"]; ?></td>
	<td><?php echo $row["192.168.5.252"]; ?></td>
	<td><?php echo $row["192.168.3.250"]; ?></td>
	<td><?php echo $row["192.168.5.249"]; ?></td>
	<td><?php echo $row["postdate"];      ?></td>
</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "No result found";
}
?>
 </body>
</html>