<!DOCTYPE HTML>
<html>
<body>
<?php
include("../DBConnection.php");
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{ 
$inOD1 = $_POST["ups1"];
$inOD2 = $_POST["dvr1"];
$inOD3 = $_POST["dvr2"];
$inOD4 = $_POST["p1"];
$inOD5 = $_POST["p2"];
$inOD6 = $_POST["fp1"];
$inOD7 = $_POST["fp2"];
$stmt = $db->prepare("INSERT INTO `otherdevices`(`192.168.5.253`, `192.168.5.52`, `192.168.3.205`, `192.168.5.229`, `192.168.5.252`, `192.168.3.250`, `192.168.5.249`) VALUES(?, ?, ?, ?, ?, ?, ?)"); //Fetching all the records with input credentials
$stmt->bind_param('sssssss', $inOD1, $inOD2, $inOD3, $inOD4, $inOD5, $inOD6, $inOD7);  //Where s indicates string type. You can use i-integer, d-double
echo $stmt->execute();
echo $result = $stmt->affected_rows;
$stmt -> close();
$db -> close(); 
if($result > 0)
{
header("location: posted.php"); // user will be taken to the success page
}
else
{
echo "Oops. Something went wrong. Please try again"; 
?>
<a href="isp_posting.php">Try Login</a>
<?php 
}
}
?>
</body> 
</html>