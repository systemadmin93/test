<!DOCTYPE HTML>
<html>
<head>
<title># Guindy Server's Post #</title>
<!-- Using external stylesheet to make the registration form look attractive -->
<link rel = "stylesheet" type = "text/css" href="Style.css"/>
<!-- Javascript validation for user inputs -->
<center> <h1>Server's Status on/off </center>
</head>

<body>
<br>
<form name="register" method="post" action="post.php" >
<!-- Not advised to use table within the form to enter user details -->
<table align="center" >
<tr>
 <!-- <td>Date and Time</td>
<td><input type="datetime-local" name="datetime" /></td>
</tr>
-->
<tr>
<td>Glpi Ticketing Portal</td><td>192.168.4.55</td>
<td><input type="radio" name="sv1" value="on" />ON <input type="radio" name="sv1" value="off" />OFF</td>
</tr>
<tr>
<td>Analyzer</td><td>192.168.4.68</td>
<td><input type="radio" name="sv2" value="on" />ON <input type="radio" name="sv2" value="off" />OFF</td>
</tr>
<tr>
<td>Active Directory - Primary(PDC) </td><td>192.168.5.2</td>
<td><input type="radio" name="sv3" value="on" />ON <input type="radio" name="sv3" value="off" />OFF</td>
</tr>
<tr>
<td>BullentProoof FTP Server - Windows</td><td>192.168.5.4</td>
<td><input type="radio" name="sv4" value="on" />ON <input type="radio" name="sv4" value="off" />OFF</td>
</tr>
<tr>
<td>Sugar CRM Portal</td><td>192.168.5.5</td>
<td><input type="radio" name="sv5" value="on" />ON <input type="radio" name="sv5" value="off" />OFF</td>
</tr>
<tr>
<td>Collabra Online Editor</td><td>192.168.5.6</td>
<td><input type="radio" name="sv6" value="on" />ON <input type="radio" name="sv6" value="off" />OFF</td>
</tr>
<tr>
<td> S10Drive - Storage Server</td><td>192.168.5.7</td>
<td><input type="radio" name="sv7" value="on" />ON <input type="radio" name="sv7" value="off" />OFF</td>
</tr>
<tr>
<td>Virtual Machine Manager - Bridge Device</td><td>192.168.5.8</td>
<td><input type="radio" name="sv8" value="on" />ON <input type="radio" name="sv8" value="off" />OFF</td>
</tr>
<tr>
<td>Active Directory - Additional(ADC) </td><td>192.168.5.9</td>
<td><input type="radio" name="sv9" value="on" />ON <input type="radio" name="sv9" value="off" />OFF</td>
</tr>
<tr>
<td>Zimra Email Server</td><td>192.168.5.10</td>
<td><input type="radio" name="sv10" value="on" />ON <input type="radio" name="sv10" value="off" />OFF</td>
</tr>
<tr>
<td>SSO Agent and SmartOffice</td><td>192.168.5.13</td>
<td><input type="radio" name="sv11" value="on" />ON <input type="radio" name="sv11" value="off" />OFF</td>
</tr>
<tr>
<td>DHCP Server - Secondary</td><td>192.168.5.16</td>
<td><input type="radio" name="sv12" value="on" />ON <input type="radio" name="sv12" value="off" />OFF</td>
</tr>
<tr>
<td>DHCP Server Primary</td><td>192.168.5.17</td>
<td><input type="radio" name="sv13" value="on" />ON <input type="radio" name="sv13" value="off" />OFF</td>
</tr>
<tr>
<td>k7 Antivirus Server </td><td>192.168.5.19</td>
<td><input type="radio" name="sv14" value="on" />ON <input type="radio" name="sv14" value="off" />OFF</td>
</tr>
<tr>
<td> Synology NAS </td><td>192.168.5.21</td>
<td><input type="radio" name="sv15" value="on" />ON <input type="radio" name="sv15" value="off" />OFF</td>
</tr>
<tr>
<td>FTP Server - Linux</td><td>192.168.5.23</td>
<td><input type="radio" name="sv16" value="on" />ON <input type="radio" name="sv16" value="off" />OFF</td>
</tr>
<tr>
<td>FTP File Share</td><td>192.168.5.24</td>
<td><input type="radio" name="sv17" value="on" />ON <input type="radio" name="sv17" value="off" />OFF</td>
</tr>
<tr>
<td>MedicalNet/MIS Server</td><td>192.168.5.33</td>
<td><input type="radio" name="sv18" value="on" />ON <input type="radio" name="sv18" value="off" />OFF</td>
</tr>
<tr>
<td>Mantis BT</td><td>192.168.5.92</td>
<td><input type="radio" name="sv19" value="on" />ON <input type="radio" name="sv19" value="off" />OFF</td>
</tr>
<tr>
<td>Asterisk Server</td><td>192.168.5.115</td>
<td><input type="radio" name="sv20" value="on" />ON <input type="radio" name="sv20" value="off" />OFF</td>
</tr>

<td><input type="submit" value="Update"></input>
<input type="reset" value="Clear"></input></td>
</tr>
</table>
</form>
</body>
</html>