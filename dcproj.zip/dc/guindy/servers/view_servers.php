<?php
include("../DBConnection.php");
$result = mysqli_query($db,"SELECT * FROM servers");
?>
<!DOCTYPE html>
<html>
 <head>
 <title># Guindy Servers - View #</title>
 </head>
<body>
<center> <h1> Guindy Server's Status Report </h1></center>
<?php
if (mysqli_num_rows($result) > 0) {
?>
<table align="center" border="2" style="background-color:powderblue;" style="width: 11px; height: 100px;" >
  <tr>
   	<th>192.168.4.55 GLPI</th>
	<th>192.168.4.68 Analyzer</th>
	<th>192.168.5.2 PrimaryDC</th>
	<th>192.168.5.4 FTP_Win</th>
	<th>192.168.5.5 SugarCRM</th>
	<th>192.168.5.6 CODE-Editor</th>
	<th>192.168.5.7 S10Drive</th>
	<th>192.168.5.8 VMM_BridgeNIC</th>
	<th>192.168.5.9 AdditionalDC</th>
	<th>192.168.5.10 ZimraMailServer</th>
	<th>192.168.5.13 SSOAgent/SmartOffice</th>
	<th>192.168.5.16 SecondaryDHCP</th>
	<th>192.168.5.17 PrimaryDHCP</th>
	<th>192.168.5.19 K7-AV</th>
	<th>192.168.5.21 SynologyNAS</th>
	<th>192.168.5.23 FTP-Linux</th>
	<th>192.168.5.24 FTP_Share</th>
	<th>192.168.5.33 MedicalNet/MIS</th>
	<th>192.168.5.92 MantisBT</th>
	<th>192.168.5.115 Asterisk</th>
	<th>checked on</th>
  </tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
   	 <td><?php echo $row["192.168.4.55"]; ?></td>
	 <td><?php echo $row["192.168.4.68"]; ?></td>
	 <td><?php echo $row["192.168.5.2"]; ?></td>
	 <td><?php echo $row["192.168.5.4"]; ?></td>
	 <td><?php echo $row["192.168.5.5"]; ?></td>
	 <td><?php echo $row["192.168.5.6"]; ?></td>
	 <td><?php echo $row["192.168.5.7"]; ?></td>
	 <td><?php echo $row["192.168.5.8"]; ?></td>
	 <td><?php echo $row["192.168.5.9"]; ?></td>
	 <td><?php echo $row["192.168.5.10"]; ?></td>
	 <td><?php echo $row["192.168.5.13"]; ?></td>
	 <td><?php echo $row["192.168.5.16"]; ?></td>
	 <td><?php echo $row["192.168.5.17"]; ?></td>
	 <td><?php echo $row["192.168.5.19"]; ?></td>
	 <td><?php echo $row["192.168.5.21"]; ?></td>
	 <td><?php echo $row["192.168.5.23"]; ?></td>
	 <td><?php echo $row["192.168.5.24"]; ?></td>
	 <td><?php echo $row["192.168.5.33"]; ?></td>
	 <td><?php echo $row["192.168.5.92"]; ?></td>
	 <td><?php echo $row["192.168.5.115"]; ?></td>
	 <td><?php echo $row["postdate"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "No result found";
}
?>
 </body>
</html>