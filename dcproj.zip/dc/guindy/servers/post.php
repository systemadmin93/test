<!DOCTYPE HTML>
<html>
<body>
<?php
include("../DBConnection.php");
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{ 
$inSv1 = $_POST["sv1"];
$inSv2 = $_POST["sv2"];
$inSv3 = $_POST["sv3"];
$inSv4 = $_POST["sv4"];
$inSv5 = $_POST["sv5"];
$inSv6 = $_POST["sv6"];
$inSv7 = $_POST["sv7"];
$inSv8 = $_POST["sv8"];
$inSv9 = $_POST["sv9"];
$inSv10 = $_POST["sv10"];
$inSv11 = $_POST["sv11"];
$inSv12 = $_POST["sv12"];
$inSv13 = $_POST["sv13"];
$inSv14 = $_POST["sv14"];
$inSv15 = $_POST["sv15"];
$inSv16 = $_POST["sv16"];
$inSv17 = $_POST["sv17"];
$inSv18 = $_POST["sv18"];
$inSv19 = $_POST["sv19"];
$inSv20 = $_POST["sv20"];
$stmt = $db->prepare("INSERT INTO `servers`(`192.168.4.55`, `192.168.4.68`, `192.168.5.2`, `192.168.5.4`, `192.168.5.5`, `192.168.5.6`, `192.168.5.7`, `192.168.5.8`, `192.168.5.9`, `192.168.5.10`, `192.168.5.13`, `192.168.5.16`,`192.168.5.17`, `192.168.5.19`, `192.168.5.21`, `192.168.5.23`, `192.168.5.24`, `192.168.5.33`, `192.168.5.92`, `192.168.5.115`) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"); //Fetching all the records with input credentials
$stmt->bind_param('ssssssssssssssssssss', $inSv1, $inSv2, $inSv3, $inSv4, $inSv5, $inSv6, $inSv7, $inSv8, $inSv9, $inSv10, $inSv11, $inSv12, $inSv13, $inSv14, $inSv15, $inSv16, $inSv17, $inSv18, $inSv19, $inSv20);  //Where s indicates string type. You can use i-integer, d-double
echo $stmt->execute();
echo $result = $stmt->affected_rows;
$stmt -> close();
$db -> close(); 
if($result > 0)
{
header("location: posted.php"); // user will be taken to the success page
}
else
{
echo "Oops. Something went wrong. Please try again"; 
?>
<a href="isp_posting.php">Try Login</a>
<?php 
}
}
?>
</body> 
</html>