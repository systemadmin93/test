<!DOCTYPE HTML>
<html>
<body>
<?php
include("../DBConnection.php"); 
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{ 
$inISP1S = $_POST["ISP1S"];
$inISP1D = $_POST["ISP1D"];
$inISP2S = $_POST["ISP2S"];
$inISP2D = $_POST["ISP2D"];
$stmt = $db->prepare("INSERT INTO `isp`(`182.75.25.129S`, `182.75.25.129D`, `43.254.110.33S`, `43.254.110.33D`) VALUES(?, ?, ?, ?)"); //Fetching all the records with input credentials
$stmt->bind_param('ssss', $inISP1S, $inISP1D, $inISP2S, $inISP2D);
echo $stmt->execute();
echo $result = $stmt->affected_rows;
$stmt -> close();
$db -> close(); 
if($result > 0)
{
header("location: posted.php");
}
else
{
echo "Oops. Something went wrong. Please try again"; 
?>
<a href="isp_posting.php">Try Login</a>
<?php 
}
}
?>
</body> 
</html>