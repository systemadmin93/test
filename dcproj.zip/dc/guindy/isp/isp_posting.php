<!DOCTYPE HTML>
<html>
<head>
<title># Guindy ISP Post #</title>
<!-- Using external stylesheet to make the registration form look attractive -->
<link rel = "stylesheet" type = "text/css" href="Style.css"/>
<!-- Javascript validation for user inputs -->
<center> <h1>Guindy ISP Status on/off and Speed </center>
</head>
<body>
<br>
<form name="register" method="post" action="post.php" >
<!-- Not advised to use table within the form to enter user details -->
<table align="center" >
<tr>
<tr>
<td>Airtel - Guindy</td><td> 182.75.25.129</td><td><input type="radio" name="ISP1S" value="on" />ON <input type="radio" name="ISP1S" value="off" />OFF</td>
<td><input type="text" name="ISP1D" /></td>
</tr>
<tr>
<td>pulse - Guindy</td><td>43.254.110.33</td><td><input type="radio" name="ISP2S" value="on" />ON <input type="radio" name="ISP2S" value="off" />OFF</td>
<td><input type="text" name="ISP2D" /></td>
</tr>
<td></td>
<td><input type="submit" value="Update"></input>
<input type="reset" value="Clear"></input></td>
</tr>
</table>
</form>
</body>
</html>