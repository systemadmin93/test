<?php
include("../DBConnection.php");
$result = mysqli_query($db,"SELECT * FROM isp");
?>
<!DOCTYPE html>
<html>
 <head>
 <title># Guindy ISP Status -View# </title>
 </head>
<body>
<center> <h1> Guindy ISP's Status Report </h1></center>
<?php
if (mysqli_num_rows($result) > 0) {
?>
 <table align="center" border="2" style="background-color:powderblue;" style="width: 11px; height: 100px;" >
  <tr>
	<th>Airtel_Status 182.75.25.129</th>
	<th>Airtel_Speed 182.75.25.129</th>
	<th>Pulse_Status 43.254.110.33</th>
	<th>Pulse_Speed 43.254.110.33</th>
	<th>Checked on</th>
  </tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
    <td><?php echo $row["182.75.25.129S"]; ?></td>
	<td><?php echo $row["182.75.25.129D"]; ?></td>
	<td><?php echo $row["43.254.110.33S"]; ?></td>
	<td><?php echo $row["43.254.110.33D"]; ?></td>
	<td><?php echo $row["postdate"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "No result found";
}
?>
 </body>
</html>