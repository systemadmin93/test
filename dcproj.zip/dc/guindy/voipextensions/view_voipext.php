<?php
include("../DBConnection.php");
$result = mysqli_query($db,"SELECT * FROM voipextensions");
?>
<!DOCTYPE html>
<html>
 <head>
 <title># Guindy Voip and Extensions -View#</title>
 </head>
<body>
<center> <h1>Guindy Voip and Extensions Status Report </h1></center>
<?php
if (mysqli_num_rows($result) > 0) {
?>
<table align="center" border="2" style="background-color:powderblue;" style="width: 11px; height: 100px;" >
  <tr>
   	<th>192.168.5.201 IT External ( IT )</th>
	<th>192.168.5.202 IT External ( Scribes)</th>
	<th>192.168.5.203 Andrea</th>
	<th>192.168.5.217  Arcaller 1</th>
	<th>192.168.3.101 IT Dev Team</th>
	<th>192.168.3.102 Accounts Dept – Sahadevan</th>
	<th>192.168.3.105 Sam Team</th>
	<th>192.168.5.205 Dennis Team</th>
	<th>192.168.5.206 Launch – Reception</th>
	<th>192.168.5.207 Sowmiya _ Payroll</th>
	<th>192.168.5.208 Austin</th>
	<th>192.168.5.209 Security</th>
	<th>192.168.5.210 Zakir</th>
	<th>192.168.5.211 Anand – HR</th>
	<th>192.168.5.212 Tamilvel </th>
	<th>192.168.5.213 Kevin Team </th>
	<th>192.168.5.214 Duke Team</th>
	<th>192.168.5.215 HR – NightShift</th>
	<th>192.168.5.216 IT Internal Team</th>
	<th>192.168.5.220 Admin</th>
	<th>checked on</th>
  </tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
   	<td><?php echo $row["192.168.5.201"]; ?></td>
	<td><?php echo $row["192.168.5.202"]; ?></td>
	<td><?php echo $row["192.168.5.203"]; ?></td>
	<td><?php echo $row["192.168.5.217"]; ?></td>
	<td><?php echo $row["192.168.3.101"]; ?></td>
	<td><?php echo $row["192.168.3.102"]; ?></td>
	<td><?php echo $row["192.168.3.105"]; ?></td>
	<td><?php echo $row["192.168.5.205"]; ?></td>
	<td><?php echo $row["192.168.5.206"]; ?></td>
	<td><?php echo $row["192.168.5.207"]; ?></td>
	<td><?php echo $row["192.168.5.208"]; ?></td>
	<td><?php echo $row["192.168.5.209"]; ?></td>
	<td><?php echo $row["192.168.5.210"]; ?></td>
	<td><?php echo $row["192.168.5.211"]; ?></td>
	<td><?php echo $row["192.168.5.212"]; ?></td>
	<td><?php echo $row["192.168.5.213"]; ?></td>
	<td><?php echo $row["192.168.5.214"]; ?></td>
	<td><?php echo $row["192.168.5.215"]; ?></td>
	<td><?php echo $row["192.168.5.216"]; ?></td>
	<td><?php echo $row["192.168.5.220"]; ?></td> 
	 <td><?php echo $row["postdate"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "No result found";
}
?>
 </body>
</html>