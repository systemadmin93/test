<!DOCTYPE HTML>
<html>
<head>
<title># Guindy Voip and Extensions #</title>
<!-- Using external stylesheet to make the registration form look attractive -->
<link rel = "stylesheet" type = "text/css" href="Style.css"/>
<!-- Javascript validation for user inputs -->
<center> <h1>Guindy Voip and Extensions Status on/off </center>
</head>
<body>
<br>
<form name="register" method="post" action="post.php" >
<table align="center" >
<tr><th>Voip</th></tr>
<tr>
<td>IT External(IT)</td><td>192.168.5.201</td><td>112/4193294819</td>
<td><input type="radio" name="ve1" value="on" />ON <input type="radio" name="ve1" value="off" />OFF</td>
</tr>
<tr>
<td>IT External(Scribes)</td><td>192.168.5.202</td><td>110/4193294820</td>
<td><input type="radio" name="ve2" value="on" />ON <input type="radio" name="ve2" value="off" />OFF</td>
</tr>
<tr>
<td>Andrea </td><td>192.168.5.203</td><td>4194191747</td>
<td><input type="radio" name="ve3" value="on" />ON <input type="radio" name="ve3" value="off" />OFF</td>
</tr>
<tr>
<td>Arcaller 1 </td><td>192.168.5.217</td><td>419557905</td>
<td><input type="radio" name="ve4" value="on" />ON <input type="radio" name="ve4" value="off" />OFF</td>
</tr>
<tr><th>Extensions</th></tr>
<tr>
<td>IT Dev Team</td><td>192.168.3.101</td><td>107</td>
<td><input type="radio" name="ve5" value="on" />ON <input type="radio" name="ve5" value="off" />OFF</td>
</tr>
<tr>
<td>Accounts Dept – Sahadevan</td><td>192.168.3.102</td><td>119</td>
<td><input type="radio" name="ve6" value="on" />ON <input type="radio" name="ve6" value="off" />OFF</td>
</tr>
<tr>
<td>Sam Team</td><td>192.168.3.105</td><td>117</td>
<td><input type="radio" name="ve7" value="on" />ON <input type="radio" name="ve7" value="off" />OFF</td>
</tr>
<tr>
<td>Dennis Team</td><td>192.168.5.205</td><td>102</td>
<td><input type="radio" name="ve8" value="on" />ON <input type="radio" name="ve8" value="off" />OFF</td>
</tr>
<tr>
<td>Launch – Reception</td><td>192.168.5.206</td><td>200</td>
<td><input type="radio" name="ve9" value="on" />ON <input type="radio" name="ve9" value="off" />OFF</td>
</tr>
<tr>
<td>Sowmiya _ Payroll</td><td>192.168.5.207</td><td>101</td>
<td><input type="radio" name="ve10" value="on" />ON <input type="radio" name="ve10" value="off" />OFF</td>
</tr>
<tr>
<td>Austin Team</td><td>192.168.5.208</td><td>114</td>
<td><input type="radio" name="ve11" value="on" />ON <input type="radio" name="ve11" value="off" />OFF</td>
</tr>
<tr>
<td>Security </td><td>192.168.5.209</td><td>100</td>
<td><input type="radio" name="ve12" value="on" />ON <input type="radio" name="ve12" value="off" />OFF</td>
</tr>
<tr>
<td>Zakir </td><td>192.168.5.210</td><td>104</td>
<td><input type="radio" name="ve13" value="on" />ON <input type="radio" name="ve13" value="off" />OFF</td>
</tr>
<tr>
<td>Anand – HR</td><td>192.168.5.211</td><td>105</td>
<td><input type="radio" name="ve14" value="on" />ON <input type="radio" name="ve14" value="off" />OFF</td>
</tr>
<tr>
<td> Tamilvel </td><td>192.168.5.212</td><td>106</td>
<td><input type="radio" name="ve15" value="on" />ON <input type="radio" name="ve15" value="off" />OFF</td>
</tr>
<tr>
<td>Kevin Team</td><td>192.168.5.213</td><td>109</td>
<td><input type="radio" name="ve16" value="on" />ON <input type="radio" name="ve16" value="off" />OFF</td>
</tr>
<tr>
<td>Duke Team</td><td>192.168.5.214</td><td>108</td>
<td><input type="radio" name="ve17" value="on" />ON <input type="radio" name="ve17" value="off" />OFF</td>
</tr>
<tr>
<td> HR – NightShift</td><td>192.168.5.215</td><td>116</td>
<td><input type="radio" name="ve18" value="on" />ON <input type="radio" name="ve18" value="off" />OFF</td>
</tr>
<tr>
<td>IT Internal Team</td><td>192.168.5.216</td><td>115</td>
<td><input type="radio" name="ve19" value="on" />ON <input type="radio" name="ve19" value="off" />OFF</td>
</tr>
<tr>
<td>Admin</td><td>192.168.5.220</td><td>118</td>
<td><input type="radio" name="ve20" value="on" />ON <input type="radio" name="ve20" value="off" />OFF</td>
</tr>
<td><input type="submit" value="Update"></input>
<input type="reset" value="Clear"></input></td>
</tr>
</table>
</form>
</body>
</html>