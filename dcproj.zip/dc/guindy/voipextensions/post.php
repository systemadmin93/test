<!DOCTYPE HTML>
<html>
<body>
<?php
include("../DBConnection.php");
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{ 
$inVE1 = $_POST["ve1"];
$inVE2 = $_POST["ve2"];
$inVE3 = $_POST["ve3"];
$inVE4 = $_POST["ve4"];
$inVE5 = $_POST["ve5"];
$inVE6 = $_POST["ve6"];
$inVE7 = $_POST["ve7"];
$inVE8 = $_POST["ve8"];
$inVE9 = $_POST["ve9"];
$inVE10 = $_POST["ve10"];
$inVE11 = $_POST["ve11"];
$inVE12 = $_POST["ve12"];
$inVE13 = $_POST["ve13"];
$inVE14 = $_POST["ve14"];
$inVE15 = $_POST["ve15"];
$inVE16 = $_POST["ve16"];
$inVE17 = $_POST["ve17"];
$inVE18 = $_POST["ve18"];
$inVE19 = $_POST["ve19"];
$inVE20 = $_POST["ve20"];
$stmt = $db->prepare("INSERT INTO `voipextensions`(`192.168.5.201`, `192.168.5.202`, `192.168.5.203`, `192.168.5.217`, `192.168.3.101`, `192.168.3.102`, `192.168.3.105`, `192.168.5.205`, `192.168.5.206`, `192.168.5.207`, `192.168.5.208`, `192.168.5.209`,`192.168.5.210`, `192.168.5.211`, `192.168.5.212`, `192.168.5.213`, `192.168.5.214`, `192.168.5.215`, `192.168.5.216`, `192.168.5.220`) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"); 
$stmt->bind_param('ssssssssssssssssssss', $inVE1, $inVE2, $inVE3, $inVE4, $inVE5, $inVE6, $inVE7, $inVE8, $inVE9, $inVE10, $inVE11, $inVE12, $inVE13, $inVE14, $inVE15, $inVE16, $inVE17, $inVE18, $inVE19, $inVE20);  //Where s indicates string type. You can use i-integer, d-double
echo $stmt->execute();
echo $result = $stmt->affected_rows;
$stmt -> close();
$db -> close(); 
if($result > 0)
{
header("location: posted.php"); // user will be taken to the success page
}
else
{
echo "Oops. Something went wrong. Please try again"; 
?>
<a href="isp_posting.php">Try Login</a>
<?php 
}
}
?>
</body> 
</html>