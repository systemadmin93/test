<body style="background-color:powderblue;">
<center>
<?php
// configuration
$url = 'http://192.168.4.55/dc/guindy/otherdevices/otherdevices_posting.php';
$file = '/var/www/html/dc/guindy/otherdevices/post.php';

// check if form has been submitted
if (isset($_POST['text']))
{
    // save the text contents
    file_put_contents($file, $_POST['text']);

    // redirect to form again
    //header(sprintf('Location: %s', $url));
    printf('<a href="%s">Click to Home</a>.', htmlspecialchars($url));
    exit();
}

// read the textfile
$text = file_get_contents($file);

?>
<!-- HTML form -->
<form action="" method="post">
<textarea rows="50" cols="100" name="text" ><?php echo htmlspecialchars($text) ?></textarea>
<input type="submit" />
<input type="reset" />
</form>
</center>
</body>

