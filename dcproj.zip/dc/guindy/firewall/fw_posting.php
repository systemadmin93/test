<!DOCTYPE HTML>
<html>
<head>
<title># Guindy Firewall Post #</title>
<!-- Using external stylesheet to make the registration form look attractive -->
<link rel = "stylesheet" type = "text/css" href="Style.css"/>
<!-- Javascript validation for user inputs -->
<center> <h1>Firewall Status on/off </center>
</head>

<body>
<br>
<form name="register" method="post" action="post.php" >
<!-- Not advised to use table within the form to enter user details -->
<table align="center" >
<tr>
 <!-- <td>Date and Time</td>
<td><input type="datetime-local" name="datetime" /></td>
</tr>
-->
<tr>
<td>Management</td><td>192.168.5.15</td>
<td><input type="radio" name="fw1" value="on" />ON <input type="radio" name="fw1" value="off" />OFF</td>
</tr>
<tr>
<td>Primary</td><td>192.168.5.188</td>
<td><input type="radio" name="fw2" value="on" />ON <input type="radio" name="fw2" value="off" />OFF</td>
</tr>
<tr>
<td>Secondary</td><td>192.168.5.189</td>
<td><input type="radio" name="fw3" value="on" />ON <input type="radio" name="fw3" value="off" />OFF</td>
</tr>
<tr>
<td></td>
<td><input type="submit" value="Update"></input>
<input type="reset" value="Clear"></input></td>
</tr>
</table>
</form>
</body>
</html>