<!DOCTYPE HTML>
<html>
<body>
<?php
include("../DBConnection.php");
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{ 
$inFw1 = $_POST["fw1"];
$inFw2 = $_POST["fw2"];
$inFw3 = $_POST["fw3"];
$stmt = $db->prepare("INSERT INTO `firewall`(`192.168.5.15`, `192.168.5.188`, `192.168.5.189`) VALUES(?, ?, ?)");
$stmt->bind_param('sss', $inFw1, $inFw2, $inFw3);  //Where s indicates string type. You can use i-integer, d-double
echo $stmt->execute();
echo $result = $stmt->affected_rows;
$stmt -> close();
$db -> close(); 
if($result > 0)
{
header("location: posted.php"); // user will be taken to the success page
}
else
{
echo "Oops. Something went wrong. Please try again"; 
?>
<a href="isp_posting.php">Try Login</a>
<?php 
}
}
?>
</body> 
</html>