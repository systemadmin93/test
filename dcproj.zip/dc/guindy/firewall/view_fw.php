<?php
include("../DBConnection.php");
$result = mysqli_query($db,"SELECT * FROM firewall");
?>
<!DOCTYPE html>
<html>
 <head>
 <title> # Guindy Firewall View #</title>
 </head>
<body>
<center> <h1> Guindy Firewall's Status Report </h1></center>
<?php
if (mysqli_num_rows($result) > 0) {
?>
<table align="center" border="2" style="background-color:powderblue;" style="width: 11px; height: 100px;" >
  <tr>
	<th>Management-192.168.5.15</th>
	<th>Primary-192.168.5.188</th>
	<th>Secondary-192.168.5.189</th>
	<th>checked on</th>
  </tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
    <td><?php echo $row["192.168.5.15"]; ?></td>
	<td><?php echo $row["192.168.5.188"]; ?></td>
	<td><?php echo $row["192.168.5.189"]; ?></td>
	<td><?php echo $row["postdate"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "No result found";
}
?>
 </body>
</html>