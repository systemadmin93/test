<?php
//Establishing connection with the database
define('DB_SERVER', 'localhost:3306');
define('DB_USERNAME', 'dc');
define('DB_PASSWORD', 'welcome');
define('DB_DATABASE', 'dc_mahalingapuram'); //where customers is the database
$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE) or die("Sorry, Unable to connect database:" . mysql_error());
?>
